**NoBuilding** is a 7 Days to Die modlet that remove player access to concrete and steel for building and upgrading

![no_construction.png](https://raw.githubusercontent.com/Laotseu/7dtdMods/master/NoBuilding/no_construction.png)
* 1.0: Initial version for 2020-09-11 stream

[Click here for Modlet Installation instruction](https://github.com/Laotseu/7dtdMods/blob/master/Modlet%20Installation.md)
[Click here for a list of all my mods](https://github.com/Laotseu/7dtdMods/blob/master/README.md)
