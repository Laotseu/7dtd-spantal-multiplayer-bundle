**ActivateBagLockSlots** Activate the lock slots counter next to the stash buttons in the player inventory window

![ActivateBagLockSlots](https://raw.githubusercontent.com/Laotseu/7dtdMods/ActivateBagLockSlots_v1.0/ActivateBagLockSlots/ActivateBagLockSlots.png)

* v1.0: Initial release
  - Activate the Locked Slots control for the player's inventory. Shout out to [Khaine](https://community.7daystodie.com/topic/19558-khaines-a19-modlets-bigger-backpacks-backpack-buttons-hp-bars-etc/) who 
    provided us with stashing buttons before b177. b177 introduced the stashing buttons for everyone, but I was missing the Locked Slots control and was not patient enough to wait for Khaine to update
    his modlet.

[Click here for Modlet Installation instruction](https://github.com/Laotseu/7dtdMods/blob/master/Modlet%20Installation.md)
[Click here for a list of all my mods](https://github.com/Laotseu/7dtdMods/blob/master/README.md)
